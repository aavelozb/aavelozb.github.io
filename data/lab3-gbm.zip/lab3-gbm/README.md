# Laboratorio 3, datos de glioblastoma

Dos pacientes de la base LUMIERE (Suter et al., 2022), estudio preoperatorio, con el craneo
removido (HD-BET) y las cuatro secuencias corregistradas al atlas MNI a 1 mm isotropico por
DeepBraTumIA. Los volumenes estan recortados a la caja que contiene al encefalo.
Orientacion LAS en voxeles, eje 2 = axial.

    patient-XXX/T1.nii.gz            T1 sin contraste (int16)
    patient-XXX/CT1.nii.gz           T1 con gadolinio (int16)
    patient-XXX/T2.nii.gz            T2 (int16)
    patient-XXX/FLAIR.nii.gz         FLAIR (int16)
    patient-XXX/brainmask.nii.gz     mascara de encefalo (uint8)
    patient-XXX/seg.nii.gz           segmentacion de referencia (uint8):
                                     1 = nucleo necrotico / no realzante
                                     2 = edema
                                     3 = tumor realzante
    patient-XXX/volumenes_mm3.json   volumen de cada compartimento

La referencia es la segmentacion automatica de DeepBraTumIA validada por los autores de
la base, no un trazado manual. Tumor completo = etiquetas 1, 2 y 3; nucleo = 1 y 3.

Citar: Suter, Y., Knecht, U., Valenzuela, W., Notter, M., Hewer, E., Schucht, P.,
Wiest, R., Reyes, M. The LUMIERE dataset: Longitudinal Glioblastoma MRI with expert
RANO evaluation. Scientific Data 9, 768 (2022). https://doi.org/10.1038/s41597-022-01881-7
